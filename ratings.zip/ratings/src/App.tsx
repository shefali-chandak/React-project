import "./App.module.scss";
import { Suspense, useContext } from "react";
import { Routes, Route } from "react-router-dom";
import Login from "./pages/Login/Login";
import Register from "./pages/Register/Register";
import { LoginContext } from "./pages/Login/LoginProvider/LoginProvider";
import { routeMap } from "./routes/routes";

function App() {
  const { loginData } = useContext(LoginContext);
  console.log(loginData);
  return (
    <Routes>
      <Route path="" element={<Register />}></Route>
      <Route path="login" element={<Login />}></Route>

      {loginData?.isLoggedIn && (
        <>
          {routeMap[loginData.role].map((route) => {
            const Element = route.element;
            return (
              <Route
                key={route.path}
                path={route.path}
                element={
                  <Suspense fallback={<div>Loading</div>}>
                    <Element />
                  </Suspense>
                }
              ></Route>
            );
          })}
        </>
      )}
    </Routes>
  );
}

export default App;
