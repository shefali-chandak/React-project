import { Suspense, useContext } from "react";
import { Routes, Route } from "react-router-dom";
import Login from "../../pages/Login/Login";
import { LoginContext } from "../../pages/Login/LoginProvider/LoginProvider";
import Register from "../../pages/Register/Register";
import { routeMap } from "../../routes/routes";

const Layout = () => {};
export default Layout;
