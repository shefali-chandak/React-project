import { Alert } from "@mui/material";

export const AlertComponent = ({ severity, setShow, message }: any) => {
  return (
    <Alert
      variant="filled"
      severity={severity}
      onClose={() => {
        setShow(false);
      }}
    >
      {message}
    </Alert>
  );
};
