import { Rating as MRating } from "@mui/material";

const Rating = ({ ...props }: React.PropsWithChildren<any>) => {
  return <MRating {...props} />;
};
export default Rating;
