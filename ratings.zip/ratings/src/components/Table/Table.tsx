import styles from "./Table.module.scss";
import { TableContainer, Paper } from "@mui/material";
import { DataGrid, GridColDef } from "@mui/x-data-grid";
import { useState } from "react";

interface ITableProp {
  columns: GridColDef[];
  rows: any;
}

const Table = ({ columns, rows }: ITableProp) => {
  const [pageSize, setPageSize] = useState<number>(5);

  return (
    <TableContainer component={Paper}>
      <div style={{ height: 500, width: "100%" }}>
        <DataGrid
          sx={{
            boxShadow: 2,
            borderColor: "primary-main",
            "& .super-app-theme--header": {
              backgroundColor: "rgba(70,130,180, 0.45)",
            },
          }}
          columns={columns}
          rows={rows}
          pageSize={pageSize}
          rowsPerPageOptions={[5, 10, 20]}
          onPageSizeChange={(newPageSize) => setPageSize(newPageSize)}
        />
      </div>
    </TableContainer>
  );
};

export default Table;
