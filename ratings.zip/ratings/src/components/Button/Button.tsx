import { Button as MButton } from "@mui/material";
import { Children } from "react";

export const Button = ({
  children,
  ...props
}: React.PropsWithChildren<any>) => {
  return (
    <MButton variant="contained" {...props}>
      {children}
    </MButton>
  );
};
