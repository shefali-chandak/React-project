import { DeepMap, FieldError, UseFormRegister, Path } from "react-hook-form";
import {
  IconButton,
  InputAdornment,
  TextField as MTextField,
} from "@mui/material";
import { useState } from "react";
import { Visibility, VisibilityOff } from "@mui/icons-material";
export interface FormTextareaProps<TFormValues> {
  name: Path<TFormValues>;
  label: string;
  type: string;
  register?: UseFormRegister<TFormValues>;
  errors?: Partial<DeepMap<TFormValues, FieldError>>;
}

export const TextField = ({
  name,
  label,
  register,
  errors,
  type,
  className,
}: any) => {
  const Tname = name;
  return (
    <MTextField
      {...register(Tname)}
      error={!!errors[Tname]}
      type={type}
      className={className}
      helperText={errors[Tname] ? errors[Tname]?.message : ""}
      label={label}
      variant="outlined"
    />
  );
};

export const PasswordField = ({
  name,
  label,
  register,
  errors,
  className,
}: any) => {
  const [showPassword, setShowPassword] = useState(false);
  const Tname = name;
  const handleClickShowPassword = () => setShowPassword(!showPassword);
  const handleMouseDownPassword = () => setShowPassword(!showPassword);
  return (
    <MTextField
      {...register(Tname)}
      error={!!errors[Tname]}
      type={showPassword ? "text" : "password"}
      className={className}
      helperText={errors[Tname] ? errors[Tname]?.message : ""}
      label={label}
      variant="outlined"
      InputProps={{
        endAdornment: (
          <InputAdornment position="end">
            <IconButton
              aria-label="toggle password visibility"
              onClick={handleClickShowPassword}
              onMouseDown={handleMouseDownPassword}
            >
              {showPassword ? <Visibility /> : <VisibilityOff />}
            </IconButton>
          </InputAdornment>
        ),
      }}
    />
  );
};
