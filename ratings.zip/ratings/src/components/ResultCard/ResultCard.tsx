import { Avatar, Paper } from "@mui/material";
import Rating from "../Rating/Rating";
import styles from "./ResultCard.module.scss";

const ResultCard = ({ ...props }: React.PropsWithChildren<any>) => {
  return (
    <Paper elevation={8}>
      <div className={styles.resultcard}>
        <Avatar sx={props.sxavatar}>{props.icontoset}</Avatar>
        <h2 style={{ fontSize: props.fontSize }}>{props.label}</h2>
        <Rating size="large" {...props} readOnly />
        <h3 style={{ fontSize: props.fontSize }}>{props.comment}</h3>
      </div>
    </Paper>
  );
};
export default ResultCard;
