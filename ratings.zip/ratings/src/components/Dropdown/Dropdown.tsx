import * as React from "react";
import InputLabel from "@mui/material/InputLabel";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";

export const Dropdown = ({ name, filter, setFilter }) => {
  const handleChange = (event) => {
    filter[event.target.name.toLowerCase()] = parseInt(event.target.value);
    setFilter({ ...filter });
    console.log(filter);
  };

  return (
    <FormControl sx={{ m: 1, minWidth: 120 }}>
      <InputLabel htmlFor="grouped-native-select">{name}</InputLabel>
      <Select
        native
        defaultValue="0"
        id="grouped-native-select"
        onChange={handleChange}
        name={name}
        label={name}
      >
        <option value={0}> 0 </option>
        <option value={1}> 1 </option>
        <option value={2}> 2 </option>
        <option value={3}> 3 </option>
        <option value={4}> 4 </option>
        <option value={5}> 5 </option>
      </Select>
    </FormControl>
  );
};
