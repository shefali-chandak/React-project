import styles from "./Register.module.scss";
import HowToRegIcon from "@mui/icons-material/HowToReg";
import { Avatar, CircularProgress, Link, Paper } from "@mui/material";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { AlertComponent } from "../../components/Alert/AlertComponent";
import { Button } from "../../components/Button/Button";
import { PasswordField, TextField } from "../../components/TextField/TextField";
import { IRegisterData } from "./Register.type";
import { SubmitHandler, useForm } from "react-hook-form";
import { useState } from "react";
// import { useNavigate } from "react-router-dom";
import { registerUser } from "../../services/auth.service";
import { Navigate, useNavigate } from "react-router-dom";
import { IUser } from "../../services/services.types";

const schema = yup.object({
  name: yup.string().max(20).required(),
  email: yup
    .string()
    .email()
    .matches(/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,20}$/)
    .required(),
  password: yup
    .string()
    .matches(
      /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/,
      "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and one special case Character"
    )
    .required(),
});

const Register = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<IRegisterData>({
    resolver: yupResolver(schema),
  });

  const [loading, setLoading] = useState(false);

  const [show, setShow] = useState(false);
  const [severity, setSeverity] = useState("error");
  const [message, setMessage] = useState("");

  const navigate = useNavigate();
  const onSubmit: SubmitHandler<IRegisterData> = async (
    data: IRegisterData
  ) => {
    setLoading(true);

    const dataReceived = await registerUser(data);
    // console.log(dataReceived.data.error.message);
    if (dataReceived.status === 200) {
      setSeverity("success");
      setMessage(dataReceived);
      setShow(true);
      setLoading(false);

      // navigate("/");
    } else {
      setSeverity("error");
      setMessage(dataReceived.data.error.message);
      setShow(true);
      setLoading(false);
      setTimeout(() => {
        setShow(false);
      }, 3000);
    }
  };

  return (
    <div className={styles.formArea}>
      <Paper elevation={8}>
        {show && (
          <AlertComponent
            severity={severity}
            setShow={setShow}
            message={message}
          />
        )}
        <form onSubmit={handleSubmit(onSubmit)} className={styles.formInput}>
          <Avatar sx={{ bgcolor: "#1976d2", width: 50, height: 50 }}>
            <HowToRegIcon />
          </Avatar>
          <h4>Register</h4>
          <TextField
            name="name"
            label="Name"
            type="text"
            register={register}
            errors={errors}
            className={styles.textarea}
          />
          <TextField
            name="email"
            label="Email"
            type="text"
            register={register}
            errors={errors}
            className={styles.textarea}
          />
          <PasswordField
            name="password"
            label="Password"
            register={register}
            errors={errors}
            className={styles.textarea}
          />

          {loading && <CircularProgress className={styles.loader} />}
          {!loading && (
            <Button variant="outlined" type="submit" className={styles.button}>
              Register
            </Button>
          )}
        </form>
        <Link
          component="button"
          variant="body2"
          className={styles.link}
          onClick={() => {
            navigate("/login");
          }}
        >
          Already have an account? Sign In
        </Link>
      </Paper>
    </div>
  );
};
export default Register;
