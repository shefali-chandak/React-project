import { Paper, Rating } from "@mui/material";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "../../components/Button/Button";
import Header from "../../components/Header/Header";
import Table from "../../components/Table/Table";
import { getRatings } from "../../services/ratings.service";
import { Dropdown } from "../../components/Dropdown/Dropdown";
import styles from "./AdminHome.module.scss";
import FilterAltIcon from "@mui/icons-material/FilterAlt";
import { GridColDef } from "@mui/x-data-grid";

const AdminHome = () => {
  const navigate = useNavigate();
  const columns: GridColDef[] = [
    {
      field: "id",
      headerName: "ID",
      width: 100,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "name",
      headerName: "Name",
      width: 250,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "ambiance",
      headerName: "Ambiance",
      width: 250,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "food",
      headerName: "Food",
      width: 250,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "service",
      headerName: "Service",
      width: 250,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "cleanliness",
      headerName: "Cleanliness",
      width: 250,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "drinks",
      headerName: "Drinks",
      width: 250,
      headerClassName: "super-app-theme--header",
    },
  ];

  const [rows, setRows] = useState<any>([]);

  const [filter, setFilter] = useState({
    ambiance: 0,
    food: 0,
    service: 0,
    cleanliness: 0,
    drinks: 0,
  });

  const [paramsData, setParamsData] = useState({
    ambiance: 0,
    food: 0,
    service: 0,
    cleanliness: 0,
    drinks: 0,
  });

  const getRatingsData = async () => {
    const data = await getRatings(paramsData);
    console.log(data["data"]);
    data["data"].map((d, i) => {
      d.id = i + 1;
    });
    console.log(data["data"]);
    setRows(data["data"]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    let data = await getRatings(filter);
    if (data["data"]) {
      data["data"].map((d, i) => {
        d.id = i + 1;
      });
      setRows(data["data"]);
    } else alert(data["data"]);
    console.log(data);
  };

  useEffect(() => {
    getRatingsData();
  }, []);

  return (
    <div className={styles.home}>
      <Header title="Admin Home" />
      <main className={styles.main}>
        <div className={styles.view}>
          <Button onClick={() => navigate("/result")}>Report</Button>
        </div>
        <div className={styles.filterTab}>
          <Paper elevation={3} className={styles.paper}>
            <h3>
              Filter Ratings
              <FilterAltIcon />
            </h3>

            <Dropdown name="Ambiance" filter={filter} setFilter={setFilter} />
            <Dropdown name="Food" filter={filter} setFilter={setFilter} />
            <Dropdown name="Service" filter={filter} setFilter={setFilter} />
            <Dropdown
              name="Cleanliness"
              filter={filter}
              setFilter={setFilter}
            />
            <Dropdown name="Drinks" filter={filter} setFilter={setFilter} />
            <Button onClick={handleSubmit} className={styles.filter}>
              Filter
            </Button>
          </Paper>
        </div>
        <div className={styles.tableContainer}>
          <Table columns={columns} rows={rows} />
        </div>
      </main>
    </div>
  );
};
export default AdminHome;
