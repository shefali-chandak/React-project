import Header from "../../components/Header/Header";
import ResultCard from "../../components/ResultCard/ResultCard";
import styles from "./Result.module.scss";
import RoomPreferencesIcon from "@mui/icons-material/RoomPreferences";
import CleaningServicesIcon from "@mui/icons-material/CleaningServices";
import FastfoodIcon from "@mui/icons-material/Fastfood";
import RoomServiceIcon from "@mui/icons-material/RoomService";
import LocalBarIcon from "@mui/icons-material/LocalBar";
import ThumbsUpDownIcon from "@mui/icons-material/ThumbsUpDown";
import { useEffect, useState } from "react";
import { getAverageRatings } from "../../services/ratings.service";
const Result = () => {
  const [ratings, setRatings] = useState({
    ambiance: 0,
    food: 0,
    service: 0,
    cleanliness: 0,
    drinks: 0,
    totalAverage: 0,
  });

  const getAverage = async () => {
    const data = await getAverageRatings();
    await setRatings(data["data"]);
    console.log(ratings);
  };

  const getComment = (rating: number) => {
    switch (rating) {
      case 1:
        return "USELESS";
      case 2:
        return "POOR";
      case 3:
        return "OK";
      case 4:
        return "GOOD";
      case 5:
        return "EXCELLENT";
    }
  };

  useEffect(() => {
    getAverage();
  }, []);
  return (
    <div className={styles.main}>
      <Header title="Result" />
      <div className={styles.top}>
        <ResultCard
          label="Ambiance"
          size="large"
          name="Ambiance"
          value={ratings.ambiance}
          comment={getComment(Math.round(ratings.ambiance))}
          sxavatar={{ height: "50px", width: "50px", bgcolor: "#1976d2" }}
          icontoset={<RoomPreferencesIcon />}
        />
        <ResultCard
          label="Cleanliness"
          size="large"
          name="Cleanliness"
          value={ratings.cleanliness}
          comment={getComment(Math.round(ratings.cleanliness))}
          sxavatar={{ height: "50px", width: "50px", bgcolor: "#1976d2" }}
          icontoset={<CleaningServicesIcon />}
        />
        <ResultCard
          label="Food"
          size="large"
          name="Food"
          value={ratings.food}
          comment={getComment(Math.round(ratings.food))}
          sxavatar={{ height: "50px", width: "50px", bgcolor: "#1976d2" }}
          icontoset={<FastfoodIcon />}
        />
        <ResultCard
          label="Service"
          size="large"
          name="Service"
          value={ratings.service}
          comment={getComment(Math.round(ratings.service))}
          sxavatar={{ height: "50px", width: "50px", bgcolor: "#1976d2" }}
          icontoset={<RoomServiceIcon />}
        />
        <ResultCard
          label="Drinks"
          size="large"
          name="Drinks"
          value={ratings.drinks}
          comment={getComment(Math.round(ratings.drinks))}
          sxavatar={{ height: "50px", width: "50px", bgcolor: "#1976d2" }}
          icontoset={<LocalBarIcon />}
        />
      </div>
      <div className={styles.bottom}>
        <ResultCard
          label="Overall Rating"
          size="large"
          name="Overall Rating"
          icontoset={<ThumbsUpDownIcon fontSize="large" />}
          value={ratings.totalAverage}
          sx={{
            fontSize: "5rem",
          }}
          fontSize="2rem"
          comment={getComment(Math.round(ratings.totalAverage))}
          sxavatar={{ height: "80px", width: "80px", bgcolor: "#198754" }}
        />
      </div>
    </div>
  );
};
export default Result;
