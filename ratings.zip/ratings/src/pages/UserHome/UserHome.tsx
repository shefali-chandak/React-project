import styles from "./UserHome.module.scss";
import { Link } from "@mui/material";
import { CircularProgress, Paper } from "@mui/material";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { AlertComponent } from "../../components/Alert/AlertComponent";
import { Button } from "../../components/Button/Button";
import { PasswordField } from "../../components/TextField/TextField";
import { SubmitHandler, useForm } from "react-hook-form";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { IRatings } from "../../services/services.types";
import { saveRatings } from "../../services/ratings.service";
import Header from "../../components/Header/Header";
import SendIcon from "@mui/icons-material/Send";
import Rating from "../../components/Rating/Rating";

const schema = yup.object({
  ambiance: yup.string().required(),
});

const UserHome = () => {
  let navigate = useNavigate();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<IRatings>({
    resolver: yupResolver(schema),
  });

  const [loading, setLoading] = useState(false);
  const [showErrorMsg, setShowErrorMsg] = useState("");
  const [ambianceRating, setAmbianceRating] = useState<number>(0);
  const [foodRating, setFoodRating] = useState<number>(0);
  const [serviceRating, setServiceRating] = useState<number>(0);
  const [cleanlinessRating, setCleanlinessRating] = useState<number>(0);
  const [drinksRating, setDrinksRating] = useState<number>(0);

  //   const { setEmail, setToken } = useGlobalAuthContext();
  const [show, setShow] = useState(false);
  const [severity, setSeverity] = useState("error");
  const [message, setMessage] = useState("");

  //   const navigate = useNavigate();
  const onSubmit: SubmitHandler<IRatings> = async (data: IRatings) => {
    setLoading(true);
    if (
      !ambianceRating ||
      !foodRating ||
      !serviceRating ||
      !cleanlinessRating ||
      !drinksRating
    ) {
      setShow(true);
      setShowErrorMsg("Please provide rating for all");
    } else {
      const objectToSend = {
        ambiance: ambianceRating,
        food: foodRating,
        service: serviceRating,
        drinks: drinksRating,
        cleanliness: cleanlinessRating,
      };
      console.log(objectToSend);
      const dataReceived = await saveRatings(objectToSend);

      console.log(localStorage.getItem("ratings-token"));
      if (dataReceived.error === null) {
        setSeverity("success");
        setMessage(dataReceived.data.message);
        setShow(true);
        console.log(dataReceived.accessToken);
        setLoading(false);
        setTimeout(() => {
          setShow(false);
        }, 3000);
      } else {
        setMessage(dataReceived.data.error.message);
        setShow(true);
        setLoading(false);
        setTimeout(() => {
          setShow(false);
        }, 3000);
      }
    }
    console.log(cleanlinessRating);
  };

  return (
    <>
      <Header title="User Home" />
      <div className={styles.formArea}>
        <Paper elevation={8}>
          {show && (
            <AlertComponent
              severity={severity}
              setShow={setShow}
              message={message}
            />
          )}
          <form onSubmit={handleSubmit(onSubmit)} className={styles.formInput}>
            <h2>Enter your Ratings </h2>
            <div className={styles.rating}>
              <span>Ambiance</span>
              <input
                type="number"
                value={ambianceRating}
                {...register("ambiance")}
                hidden
                readOnly
              />
              <Rating
                size="large"
                name="ambiance"
                value={ambianceRating}
                onChange={(event: Event, newValue: number) => {
                  setAmbianceRating(newValue);
                }}
              />
            </div>
            <div className={styles.rating}>
              <span>Food</span>
              <input
                type="number"
                value={foodRating}
                {...register("food")}
                hidden
                readOnly
              />
              <Rating
                size="large"
                name="food"
                value={foodRating}
                onChange={(event: Event, newValue: number) => {
                  setFoodRating(newValue);
                }}
              />
            </div>
            <div className={styles.rating}>
              <span>Service</span>
              <input
                type="number"
                value={serviceRating}
                {...register("service")}
                hidden
                readOnly
              />
              <Rating
                size="large"
                name="service"
                value={serviceRating}
                onChange={(event: Event, newValue: number) => {
                  setServiceRating(newValue);
                }}
              />
            </div>
            <div className={styles.rating}>
              <span>Cleanliness</span>
              <input
                type="number"
                value={cleanlinessRating}
                {...register("cleanliness")}
                hidden
                readOnly
              />
              <Rating
                size="large"
                name="cleanliness"
                value={cleanlinessRating}
                onChange={(event: Event, newValue: number) => {
                  setCleanlinessRating(newValue);
                }}
              />
            </div>
            <div className={styles.rating}>
              <span>Drinks</span>
              <input
                type="number"
                value={drinksRating}
                {...register("drinks")}
                hidden
                readOnly
              />
              <Rating
                size="large"
                name="drinks"
                value={drinksRating}
                onChange={(event: Event, newValue: number) => {
                  setDrinksRating(newValue);
                }}
              />
            </div>

            {loading && <CircularProgress className={styles.loader} />}
            {!loading && (
              <Button type="submit" className={styles.button}>
                Submit
              </Button>
            )}
          </form>
        </Paper>
      </div>
    </>
  );
};
export default UserHome;
