export const ROLES = {
  ADMIN: 2,
  USER: 1,
};
