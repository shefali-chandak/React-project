export interface ILoginData {
  usernameOrEmail: string;
  password: string;
}
