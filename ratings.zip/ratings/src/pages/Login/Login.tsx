import styles from "./Login.module.scss";
import { ROLES } from "./Login.constants";
import { Link } from "@mui/material";
import { Avatar, CircularProgress, Paper } from "@mui/material";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import LoginIcon from "@mui/icons-material/Login";
import { AlertComponent } from "../../components/Alert/AlertComponent";
import { Button } from "../../components/Button/Button";
import { PasswordField, TextField } from "../../components/TextField/TextField";
import { ILoginData } from "./Login.type";
import { SubmitHandler, useForm } from "react-hook-form";
import { useContext, useState } from "react";
import { login } from "../../services/auth.service";
import { useNavigate } from "react-router-dom";
import { ICredentials } from "../../services/services.types";
import { LoginContext } from "./LoginProvider/LoginProvider";

const schema = yup.object({
  usernameOrEmail: yup
    .string()
    .email()
    .matches(/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,20}$/)
    .required(),
  password: yup
    .string()
    .matches(
      /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/,
      "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and one special case Character"
    )
    .required(),
});

const Login = () => {
  let navigate = useNavigate();

  const loginContext = useContext(LoginContext);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ILoginData>({
    resolver: yupResolver(schema),
  });

  const [loading, setLoading] = useState(false);
  const [show, setShow] = useState(false);
  const [message, setMessage] = useState("");

  const onSubmit: SubmitHandler<ILoginData> = async (data: ICredentials) => {
    setLoading(true);
    console.log(data);

    const dataReceived = await login(data);

    if (dataReceived.error === null) {
      setShow(true);
      console.log(dataReceived.data.role + "/" + ROLES.USER);
      const role = dataReceived.data.role === ROLES.USER ? "USER" : "ADMIN";
      loginContext.onLogin({
        token: dataReceived.data.accessToken,
        role: role,
      });
      setLoading(false);
      navigate("/home");
    } else {
      setMessage(dataReceived.data.error.message);
      setShow(true);
      setLoading(false);
      setTimeout(() => {
        setShow(false);
      }, 3000);
    }
  };

  return (
    <div className={styles.formArea}>
      <Paper elevation={8}>
        {show && (
          <AlertComponent
            severity="error"
            setShow={setShow}
            message={message}
          />
        )}
        <form onSubmit={handleSubmit(onSubmit)} className={styles.formInput}>
          <Avatar sx={{ bgcolor: "#1976d2", width: 50, height: 50 }}>
            <LoginIcon />
          </Avatar>
          <h4>Sign In</h4>
          <TextField
            name="usernameOrEmail"
            label="Email"
            type="text"
            register={register}
            errors={errors}
            className={styles.textarea}
          />
          <PasswordField
            name="password"
            label="Password"
            register={register}
            errors={errors}
            className={styles.textarea}
          />

          {loading && <CircularProgress className={styles.loader} />}
          {!loading && (
            <Button
              variant="outlined"
              type="submit"
              text="Login"
              className={styles.button}
            >
              Login
            </Button>
          )}
        </form>
        <Link
          component="button"
          variant="body2"
          className={styles.link}
          onClick={() => {
            navigate("/");
          }}
        >
          Don't have an account? Sign Up
        </Link>
      </Paper>
    </div>
  );
};
export default Login;
