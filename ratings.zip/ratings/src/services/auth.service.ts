import axios from "./axios.instance";
import { ICredentials, IUser } from "./services.types";

export const login = async (credentials: ICredentials) => {
  try {
    const response = await axios.post("/api/auth/login", credentials);

    const { accessToken } = response.data.data;
    localStorage.setItem("ratings-token", accessToken);

    return response.data;
  } catch (e: any) {
    return e.response;
  }
};

export const registerUser = async (user: IUser) => {
  try {
    const response = await axios.post("/api/auth/register", user);
    return response.data;
  } catch (e: any) {
    return e.response;
  }
};
