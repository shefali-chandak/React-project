export interface ICredentials {
  usernameOrEmail: string;
  password: string;
}

export interface IUser {
  name: string;
  email: string;
  password: string;
}

export interface IRatings {
  ambiance: number;
  food: number;
  service: number;
  cleanliness: number;
  drinks: number;
  name?: number;
  average?: number;
}
