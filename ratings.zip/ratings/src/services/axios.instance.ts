import axios from "axios";

const BaseURL = "https://b7ec-103-51-153-190.in.ngrok.io/";
const axiosInstance = axios.create({
  baseURL: BaseURL,
});

axiosInstance.interceptors.request.use((config) => {
  const token = localStorage.getItem("ratings-token");
  config.headers = {
    Authorization: `Bearer ${token}` || "",
  };
  return config;
});

export default axiosInstance;
