import axios from "./axios.instance";
import { IRatings } from "./services.types";

export const getRatings = async (
  params: IRatings
): Promise<{ records: any }> => {
  try {
    const response = await axios.get(`/admin/`, {
      params: params,
    });
    return response.data;
  } catch (e: any) {
    return e.response;
  }
};

export const getAverageRatings = async (): Promise<{ records: IRatings }> => {
  try {
    console.log(localStorage.getItem("ratings-token"));
    const response = await axios.get("/admin/averageRatings");
    return response.data;
  } catch (e: any) {
    return e.response;
  }
};

export const saveRatings = async (ratings: IRatings) => {
  try {
    const response = await axios.post("/api/auth/ratings", ratings);
    return response.data;
  } catch (e: any) {
    return e.response;
  }
};
