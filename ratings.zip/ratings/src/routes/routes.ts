import React from "react";

const Login = React.lazy(() => import("../pages/Login/Login"));
const AdminHome = React.lazy(() => import("../pages/AdminHome/AdminHome"));
const UserHome = React.lazy(() => import("../pages/UserHome/UserHome"));
const Result = React.lazy(() => import("../pages/Result/Result"));

export const routeMap: {
  [key: string]: {
    path: string;
    element: React.LazyExoticComponent<() => JSX.Element>;
  }[];
} = {
  ADMIN: [
    { path: "home", element: AdminHome },
    { path: "result", element: Result },
  ],
  USER: [{ path: "home", element: UserHome }],
  "": [{ path: "/", element: Login }],
};
